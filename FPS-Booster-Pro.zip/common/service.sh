#!/system/bin/sh
MODDIR=${0%/*}

sleep 60
$MODDIR/fpsbooster 2>/dev/null